<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Playa's that are alive</div>

                    <div class="card-body">
                        <ol>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                <a href="stats/<?php echo e($user->id); ?>"><li style="text-align: center; list-style-type: none; margin-left: -30px;" class="border py-3 px-3 mb-3">
                                         <?php echo e($user->name); ?>

                                </a>


                                    <div class="float-left">
                                    <a href="users/<?php echo e($user->id); ?>/edit">
                                        <button style="margin-top: -5px;" class="btn btn-sm btn-outline-warning mr-2"><i class="far fa-edit"></i> Edit</button>
                                    </a>
                                    </div>
                                    <div class="float-right">
                                        <form style="display: inline-block;" action="/users/<?php echo e($user->id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        <button style="margin-top: -5px;" class="btn btn-sm btn-danger float-right"><i class="fa fa-trash"></i></button>
                                        </form>
                                    </div>



                                </li>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>