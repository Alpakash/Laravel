<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <div class="row justify-content-center">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-danger">
                    <center><?php echo e(session()->get('message')); ?></center>
                </div>
            <?php endif; ?>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e($games[$id-1]->name); ?> <img src="<?php echo e($games[$id-1]->img); ?>" width="40px" style="margin-left:5px;"></div>
                    <div class="card-body">

                        <form action="<?php echo e(url('/battles')); ?>/store" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="name">Battle Name</label>

                                    <input type="text" class="form-control mt-2" name="name" placeholder="Write a cool battle name.." value="<?php echo e(old('name')); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="players">Select between <strong><?php echo e($games[$id-1]->min_players); ?></strong> and <strong><?php echo e($games[$id-1]->max_players); ?></strong> players</label>
                                    <select class="selectpicker form-control" multiple data-live-search="true" name="user_id[]" required>
                                        <!-- Execute all usernames out of the users table -->
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $temp_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <input type="number" name="game_id" value="<?php echo e($id); ?>" hidden>
                                <input type="number" name="battle_img" value="<?php echo e($games[$id-1]->battle_img); ?>" hidden>
                                <div class="col-md-4 mt-4">
                                    <input type="submit" class="center-block btn btn-success" value="Create Battle">
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>