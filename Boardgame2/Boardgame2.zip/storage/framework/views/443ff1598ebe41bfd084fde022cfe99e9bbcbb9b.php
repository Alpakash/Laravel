<?php $__env->startSection('content'); ?>

    <div class="container mt-4">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <center><?php echo e(session()->get('message')); ?></center>
            </div>
        <?php endif; ?>

        <h1 class="text-center mb-5"><?php echo e(count($battles)); ?> <?php echo e($battles[0]->game_name); ?> battles             <a class="btn btn-primary" href="/battles/1/create">Play GOT <img src="<?php echo e($battles[2]->img); ?>" width="40px" style="margin-left:5px;"></a>
        </h1>

        <ul class="list-group">
            <ul class="list-group">
            <?php $__currentLoopData = $battles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $battle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <!-- Get the date and time of the battles and format them in day-month-year and show time played game-->
                    <div>
                        <center>
                            <strong>Played Date:</strong> <?php echo e(date("d-m-Y ", strtotime($battle->played_date))); ?> -
                            <strong>Time:</strong> <?php echo e(date("H:i:s", strtotime($battle->played_date))); ?> -
                            <strong>Ultimate winner: </strong> <?php echo e($battle->won_by); ?>

                        </center>
                    </div>
                    <a style="width: 70%; margin: auto;" class="game-overview game-hover mt-1 mb-5" href="<?php echo e(url("/battles/{$battle->id}")); ?>">
                        <!-- echo each username in the database in the users table -->
                        <li class='game-hover list-group-item clearfix smaller-li'>
                            <center> <?php echo e(ucfirst($battle->name)); ?> <img src="<?php echo e($battle->img); ?>" width="40px"; style="float:right;"> </center>
                        </li></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>