<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <div class="col-md-12">
            <div class="card" style="background-image: url(https://www.battlefields.org/sites/default/files/styles/scale_crop_1280x450/public/thumbnails/image/Gettysburg%20Battle%20Page%20Hero.jpg?itok=l4MbvlMp);background-size: cover;">
                <div class="text-white text-center align-items-center px-4 my-4">
                    <div>
                        <h1 class="card-title pt-3 mb-5 font-bold"><strong>The Battlefield</strong></h1>
                        <p class="mx-5 mb-5">It is better to conquer yourself than to win a thousand battles. Then the victory is yours. It cannot be taken from you, not by angels or by demons, heaven or hell.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-4">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <center><?php echo e(session()->get('message')); ?></center>
        </div>
    <?php endif; ?>
<center>
        <a class="btn btn-primary" href="<?php echo e(url('/battles/1/create')); ?>">Play GOT <img src="<?php echo e($games[0]->img); ?>" width="40px" style="margin-left:5px;"></a>
        <a class="btn btn-primary" href="<?php echo e(url('/battles/2/create')); ?>">Play WOW <img src="<?php echo e($games[1]->img); ?>" width="40px" style="margin-left:5px;"></i></a>
        <a class="btn btn-primary" href="<?php echo e(url('/battles/3/create')); ?>">Play LOTR <img src="<?php echo e($games[2]->img); ?>" width="40px" style="margin-left:5px;"></a>
        </center>
        <br><br><br>

        <ul class="list-group">

        <?php $__currentLoopData = $battles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $battle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- Get the date and time of the battles and format them in day-month-year and show time played game-->
            <div>
                <center>
                    <strong>Played Date:</strong> <?php echo e(date("d-m-Y ", strtotime($battle->played_date))); ?> -
                    <strong>Time:</strong> <?php echo e(date("H:i:s", strtotime($battle->played_date))); ?> -
                    <strong>Ultimate winner: </strong> <?php if(isset(\App\User::find($battle->won_by)->name)) : ?><?php echo e(\App\User::findOrFail($battle->won_by)->name); ?> <?php endif; ?>
                </center>
            </div>
            <a style="width: 70%; margin: auto;" class="game-overview game-hover mt-1 mb-5" href="<?php echo e(url("/battles/{$battle->id}")); ?>">
                    <!-- echo each username in the database in the users table -->
                <li class='game-hover list-group-item clearfix smaller-li'>
                  <center><strong><?php echo e($battle->game['name']); ?>:</strong> <?php echo e(ucfirst($battle->name)); ?> <img src="<?php echo e($battle->game->img); ?>" width="40px"; style="float:right;"> </center>
                </li></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>