<?php $__env->startSection('content'); ?>
    
    <div class="mb-4">
        <div class="col-md-12">
            <div class="card" style="background-image: url(https://images5.alphacoders.com/389/389431.jpg);background-size: cover;">
                <div class="text-white text-center align-items-center px-4 my-4">
                    <div>
                        <h1 class="card-title pt-3 mb-5 font-bold"><strong>Statistics fam</strong></h1>
                        <p class="mx-5 mb-5">Two plus two is four, minus one that's three, quick maths
                            Everyday man's on the block, smoke trees
                            See your girl in the park, that girl is a uckers
                            When the ting went quack-quack-quack, you man were ducking (you man ducked).
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Insane stats of user: <?php echo e($username); ?></div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="cardBorder">
                            <div class="profileIcon"> <i class="fas fa-id-card"></i> </div>

                            <div class="profileLabel"><strong>Name:</strong><p> <?php echo e($username); ?> </p></div>
                        </div>

                        <div class="cardBorder">
                            <div class="profileIcon"> <i class="fas fa-trophy"></i></div>
                            <div class="profileLabel"><strong>Last Game:</strong><p> <?php if(isset($lastPlayedGame)): ?> <?php echo e($lastPlayedGame); ?> <?php endif; ?></p></div>
                        </div>

                        <div class="cardBorder">
                            <div class="profileIcon"> <i class="fas fa-list-alt"></i> </div>
                            <div class="profileLabel"> <strong>Battles:</strong><p> <?php if(isset($battlesPlayed)): ?> <?php echo e($battlesPlayed); ?> battles played <?php endif; ?></p></div>
                        </div>

                        <div class="cardBorder">
                            <div class="profileIcon"> <i class="fas fa-forward"></i> </div>
                            <div class="profileLabel">
                                <strong>Winning rate:</strong><p> <?php if(isset($winningRatio)): ?> <?php echo e($battlesWon); ?>  of  <?php echo e($battlesPlayed); ?>  victories /  <?php echo e($winningRatio); ?>% <?php endif; ?></p>
                            </div>
                        </div>
                        <div class="cardBorder">
                            <div class="profileIcon"> <i class="fas fa-plus-square"></i> </div>
                            <div class="profileLabel">
                                <strong>Account created:</strong><p> <?php echo e(\Carbon\Carbon::parse(Auth::user()->created_at)->format('d-m-Y')); ?></p>
                            </div>
                        </div>

                            <center><a href='<?php echo e(url('/players')); ?>'><button class="btn btn-primary form-control mt-3 mb-2">Back to players</button></a></center>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>