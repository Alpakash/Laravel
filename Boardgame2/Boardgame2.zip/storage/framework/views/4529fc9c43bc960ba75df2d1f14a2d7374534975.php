<?php $__env->startSection('content'); ?>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card" style="background-image: url(https://mdbootstrap.com/img/Photos/Others/gradient1.jpg);">
                <div class="text-white text-center d-flex align-items-center py-5 px-4 my-5">
                    <div>
                        <h1 class="card-title pt-3 mb-5 font-bold"><strong>Games are educative.</strong></h1>
                        <p class="mx-5 mb-5">Just play. Have fun. Enjoy the game.There are at least two kinds of games. One could be called finite, the other infinite.
                            A finite game is played for the purpose of winning,
                            an infinite game for the purpose of continuing the play.</p>
                        <a class="btn btn-primary" href="#games">Start playing <i class="fa fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container mt-4">
        <!--News card-->
        <div id="games" class="card border mb-4 text-center hoverable">
            <div class="card-body">
                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-4 offset-md-1 mx-3 my-3">
                        <!--Featured image-->
                        <div class="view overlay hm-white-slight">
                            <img src="https://www.lautapelit.fi/images/tuotekuvat/kuva400/lautapelit/game-of-thrones-2nd-edition.jpg" width="280px" class="img-fluid" alt="Sample image for first version of blog listing">
                            <a>
                                <div class="mask"></div>
                            </a>
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-md-7 text-left ml-3 mt-3">
                        <!--Excerpt-->
                        <a href="" class="green-text">
                            <h6 class="font-bold pb-1"><i class="fa fa-info-circle"></i> Work</h6>
                        </a>
                        <h4 class="mb-4"><strong>This is title of the news</strong></h4>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                            rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae
                            dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur.</p>
                        <p>by <a><strong>Carine Fox</strong></a>, 19/08/2016</p>
                        <a class="btn btn-success">Read more</a>
                    </div>
                    <!--Grid column-->
                </div>
                <!--Grid row-->
            </div>
        </div>
        <!--News card-->

        <!--News card-->
        <div class="card border mb-4 text-center hoverable">
            <div class="card-body">
                <!--Grid row-->
                <div class="row">


                    <!--Grid column-->
                    <div class="col-md-7 text-left ml-3 mt-3">
                        <!--Excerpt-->
                        <a href="" class="green-text">
                            <h6 class="font-bold pb-1"><i class="fa fa-info-circle"></i> Work</h6>
                        </a>
                        <h4 class="mb-4"><strong>This is title of the news</strong></h4>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                            rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae
                            dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur.</p>
                        <p>by <a><strong>Carine Fox</strong></a>, 19/08/2016</p>
                        <a class="btn btn-success">Read more</a>
                    </div>


                    <!--Grid column-->
                    <div class="col-md-4 offset-md-1 mx-3 my-3">
                        <!--Featured image-->
                        <div class="view overlay hm-white-slight">
                            <img src="http://i.ebayimg.com/00/s/NTAwWDUwMA==/z/DhwAAOxyOMdS-tAQ/$_3.JPG?set_id=2" width="280px" class="img-fluid" alt="Sample image for first version of blog listing">
                            <a>
                                <div class="mask"></div>
                            </a>
                        </div>
                    </div>
                    <!--Grid column-->
                    <!--Grid column-->
                </div>
                <!--Grid row-->
            </div>
        </div>
        <!--News card-->

        <!--News card-->
        <div id="games" class="card border mb-4 text-center hoverable">
            <div class="card-body">
                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-4 offset-md-1 mx-3 my-3">
                        <!--Featured image-->
                        <div class="view overlay hm-white-slight">
                            <img src="https://images-na.ssl-images-amazon.com/images/I/914GYKLDR-L._SX466_.jpg" class="img-fluid" width="280px" alt="Sample image for first version of blog listing">
                            <a>
                                <div class="mask"></div>
                            </a>
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-md-7 text-left ml-3 mt-3">
                        <!--Excerpt-->
                        <a href="" class="green-text">
                            <h6 class="font-bold pb-1"><i class="fa fa-info-circle"></i> Work</h6>
                        </a>
                        <h4 class="mb-4"><strong>This is title of the news</strong></h4>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam
                            rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae
                            dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur.</p>
                        <p>by <a><strong>Carine Fox</strong></a>, 19/08/2016</p>
                        <a class="btn btn-success">Read more</a>
                    </div>
                    <!--Grid column-->
                </div>
                <!--Grid row-->
            </div>
        </div>
        <!--News card-->

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>