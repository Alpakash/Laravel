<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <div class="col-md-12">
            <div class="card" style="background-image: url(https://mdbootstrap.com/img/Photos/Others/gradient1.jpg);background-repeat: no-repeat;background-size: cover;">
                <div class="text-white text-center align-items-center py-5 px-4 my-5">
                    <div>
                        <center><h1 class="card-title pt-3 mb-5 font-bold"><strong>Total battles played: <?php echo e($totalBattlesPlayed); ?></strong></h1>
                        <p class="mx-5 mb-5">Just play. Have fun. Enjoy the game.There are at least two kinds of games. One could be called finite, the other infinite.
                            A finite game is played for the purpose of winning,
                            an infinite game for the purpose of continuing the play.</p>
                        <a class="btn btn-success" href="<?php echo e(url('games')); ?>">Games version 1</a>
                        <a class="btn btn-primary" href="#games">Start playing <i class="fa fa-chevron-down"></i></a></center>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-5">



    <!-- Card deck -->
    <div id="games" class="card-deck">

        <!-- Card -->
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <!--Card image-->
            <div class="view overlay">
                <img class="card-img-top" src="<?php echo e($game->battle_img); ?>" height="250" alt="Card image cap">
                <a href="#!">
                    <div class="mask rgba-white-slight"></div>
                </a>
            </div>

            <!--Card content-->
            <div class="card-body">

                <!--Title-->

                <h4 class="text-center card-title"><?php echo e($game->name); ?></h4>
                <p><em>Battles played: <?php echo e(count($game->battle)); ?></em></p>

                <!--Text-->
                <p class="card-text"><?php echo e($game->description); ?></p>

                <p class="card-text">
                    <strong>Last winner:</strong> <?php echo e($game->winner); ?>

                </p>
                <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
                <a href="<?php echo e(url('/battles')); ?>/<?php echo e($game->id); ?>/create"><button type="button" class="form-control btn btn-success btn-md"><i class="fas fa-play"></i> Play game</button></a>
                <a href="<?php echo e(url('/battles')); ?>/game/<?php echo e($game->release_date); ?>"><button type="button" class="form-control btn btn-green btn-md"><i class="far fa-list-alt"></i> See battles</button></a>

            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Card -->
    </div>
    <!-- Card deck -->

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>