17 januari 2019:

Beste lezer,

Welkom bij het Carcassonne project van team 11 ADSD jaar 1.

Om het project werkende te krijgen zijn er maar een paar kleine stappen nodig.

1. composer install
2. npm install
3. php artisan db:seed

accounts voor diverse rollen:
admin@admin.nl
ww: secret

judge@judge.nl
ww: secret

user@user.nl
ww: secret


Enjoy the project, cheers team 11!
