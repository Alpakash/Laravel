<!--Footer-->
<footer class="page-footer text-center font-small bg-home darken-2 mt-4 wow fadeIn ">


    <hr class="my-4">
    <!--Copyright-->
    <div class="footer-copyright py-3">
        © 2018 Copyright:
        <a href="#" target="_blank"> 999games.com </a>
    </div>
    <!--/.Copyright-->

</footer>
<!--/.Footer-->