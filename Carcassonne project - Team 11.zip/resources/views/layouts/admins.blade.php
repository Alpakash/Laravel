<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

<div class="card mb-4 mt-4">
<div class="card-header"><strong>Judge dashboard</strong><span class="float-right">Fill in the countdown timer</span></div>

<div class="card-body">
@include('layouts.cd-buttons')
</div>
</div>


            <div class="card">
                <div class="card-header"><strong>Admins</strong><span class="float-right">15 admins are at the Carcassonne NK</span></div>

                <div class="card-body">

              <div class="cardBorder">
                 <center><p>{{ Auth::user()->name }}</p></center>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>