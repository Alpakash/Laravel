<h1 style="text-align: center;"><strong>Hallo, {{ $email }}</strong></h1>
<p>Welkom bij carcasonne</p><br />
<p>Er is een account voor jou aangemaakt. Klik op de knop hieronder om eenvoudig account aan te maken</p>
<a href="http://localhost:8000/register?email={{$email}}&hash={{$hash}}">Klik op deze link</a>
http://localhost:8000/register?email={{$email}}&hash={{$hash}}
<p>Vriendelijke groet,</p>
<p><strong>Carcassonne 2018</strong></p>