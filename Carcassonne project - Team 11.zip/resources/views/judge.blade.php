@extends('layouts.app')
@section('content')
@include('admins')
@endsection