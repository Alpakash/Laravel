@extends('layouts.app')
@section('content')
@include('layouts.admins')
@endsection