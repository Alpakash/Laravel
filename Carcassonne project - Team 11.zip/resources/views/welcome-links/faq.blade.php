@extends('layouts.app')
@section('content')
@include('layouts.faq')
@endsection