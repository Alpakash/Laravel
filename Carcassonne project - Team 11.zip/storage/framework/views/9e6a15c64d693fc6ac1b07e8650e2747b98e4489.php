<div class="w-100">
    
    <table id="userTable" class="table  mt-3" width="100%" style="border-collapse: initial !important;" >
        <thead>
        <tr>
            <th scope="col">voornaam</th>
            <th scope="col">achternaam</th>
            <th scope="col">email</th>
            <th scope="col">Geactiveerd</th>
            <th scope="col">Actie</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($user['name']); ?></td>
                <td><?php echo e($user['lastName']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td>
                    <span class="checkIcon checkIcon<?php echo e(($user->email_verified_at)? 'Green' : 'Red'); ?> round-btn">
                        <a class="btn d-flex justify-content-center align-items-center p-0">
                            <i class="fas fa-<?php echo e(($user->email_verified_at)? 'check' : 'times'); ?>"></i>
                        </a>
                    </span>
                </td>
                <td class="d-flex justify-content-start">
                    <span class="pencilIcon round-btn mr-3">
                        <a href="<?php echo e(route("admin.$name.show", $user->id)); ?>" class="btn d-flex justify-content-center align-items-center p-0">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                    </span>
                    <span class="trashIcon round-btn">
                        <a href="" class="btn d-flex justify-content-center align-items-center p-0">
                           <i class="fas fa-trash-alt"></i>
                        </a>
                    </span>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>