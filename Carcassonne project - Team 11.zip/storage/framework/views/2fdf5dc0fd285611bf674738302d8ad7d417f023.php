<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="grey lighten-3 preload">
    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
        <div class="container-fluid">

        
        
        
        

        <!-- Collapse -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Links -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item">
                            <?php if(Route::has('register')): ?>
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            <?php endif; ?>
                        </li>
                    <?php else: ?>

                        <li class="nav-item">
                            <a href="<?php echo e(url('/profile')); ?>"><button class="btn btn-danger mr-3"><i class="fa fa-book"></i> Profiel</button></a>
                        </li>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class=" dropdown-toggle btn btn-warning" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <i class="fas fa-user"></i>  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(url('/news')); ?>">
                                    <i class="far fa-newspaper"></i>  News
                                </a>
                                <a class="dropdown-item" href="<?php echo e(url('/faq')); ?>">
                                    <i class="fas fa-question"></i> FAQ
                                </a>
                                <a class="dropdown-item" href="<?php echo e(url('/scores')); ?>">
                                    <i class="far fa-star"></i>  Scores
                                </a>
                                <a class="dropdown-item" href="<?php echo e(url('/judge')); ?>">
                                    <i class="fas fa-crown"></i> Judge
                                </a>

                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <i class="fas fa-sign-out-alt"></i>  <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>

            </div>

        </div>
    </nav>
    <!-- Navbar -->
    <?php if(Session::has('msg-success')): ?>
        <div class="message-wrap box-shadow">
            <div class="d-flex flex-row justify-content-center align-items-center">
                <span><?php echo session('msg-success'); ?></span>
            </div>
        </div>
    <?php elseif(Session::has('msg-danger')): ?>
        <div class="message-wrap danger box-shadow">
            <div class="d-flex flex-row justify-content-center align-items-center">
                <span><?php echo session('msg-success'); ?></span>
            </div>
        </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>

    
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
