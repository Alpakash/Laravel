<form method="POST" action="<?php echo e(route('news.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group row">
        <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Title')); ?></label>

        <div class="col-md-6">
            <input id="title" type="text" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" required autofocus>

            <?php if($errors->has('title')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>

    <div class="form-group row">
        <label for="name" class="col-md-4 col-form-label text-md-right">Description</label>

        <div class="col-md-6">
           <textarea style="width: 80%;height: 50%;" name="desc"></textarea>
            <?php if($errors->has('desc')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('desc')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>



<br>
 
    <div class="form-group row mb-0">
        <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn btn-primary">Nieuw News</button>
        </div>
    </div>
</form>