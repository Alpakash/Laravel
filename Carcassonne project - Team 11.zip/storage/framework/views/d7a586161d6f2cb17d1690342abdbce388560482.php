<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-4 mb-4">
                <div style="text-align: center;" class="card-header"><strong>Dashboard</strong></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="cardBorder">
                 <div class="profileIcon"> <i class="fas fa-id-card"></i> </div>
                 
                 <div class="profileLabel"><strong>Name:</strong><p> <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastName); ?></p></div>
                    </div>

   <div class="cardBorder">
       <div class="profileIcon"> <i class="fas fa-forward"></i> </div>
       <div class="profileLabel">

               <strong>Upcoming match:</strong>
           <p>
               <?php if(isset($users_table)): ?>
               <?php $__currentLoopData = $users_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tableData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php echo e($tableData->name); ?><?php if(count($users_table) != $key+1): ?>,<?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               <?php if(isset($users_table[0])): ?> @ Table <?php echo e($users_table[0]->table_id); ?>


               <?php else: ?> No upcoming match <?php endif; ?>

               <?php else: ?>
                   No upcoming match
                   <?php endif; ?>
           </p>

       </div>
   </div>
  <div class="cardBorder">
       <div class="profileIcon"> <i class="fas fa-plus-square"></i> </div>
       <div class="profileLabel"> 
                  <strong>Account created at:</strong><p> <?php echo e(\Carbon\Carbon::parse(Auth::user()->created_at)->format('d-m-Y')); ?></p>
       </div>
    </div>

    <center><a href="<?php echo e(url('/welcome')); ?>"><button class="btn btn-danger form-control">Watch Carcassonne Insights</button></a></center>
        <?php if(Auth::user()->isAdmin()): ?>
                        <center><a href="<?php echo e(url('/admin')); ?>"><button class="btn btn-primary form-control">Admin Dashboard</button></a></center>
        <?php elseif(Auth::user()->isJudge() || Auth::user()->isAdmin()): ?>
                        <center><a href="<?php echo e(url('/judge')); ?>"><button class="btn btn-primary form-control">Judge Page</button></a></center>
                    <?php endif; ?>

                        <?php if(Auth::user()->isAdmin() || Auth::user()->isJudge()): ?>
                            <center><a href="<?php echo e(url('/scores')); ?>"><button class="btn btn-success form-control">Scores invoeren</button></a></center>
                        <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>