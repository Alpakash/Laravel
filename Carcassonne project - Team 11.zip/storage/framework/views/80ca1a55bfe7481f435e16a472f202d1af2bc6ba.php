<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php if(Session::has('msg-success')): ?>
        <main class="pt-5 mx-lg-5 ">
            <div class="container-fluid mt-5">
                    <span><?php echo session('msg-success'); ?></span>
                </div>
            </div>
        </main>
    <?php endif; ?>
    <div class="" style="height: 100vh;background-image: url('http://www.pirineuemocio.com/wp-content/uploads/2015/08/excursion-a-carcassone.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center;")>
        <div class="mask d-flex justify-content-center align-items-center">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
