<?php $__env->startSection('content'); ?>
    <?php
$usersOnTable = count($usersPerTable[$table_id]);
    ?>

    <div class="container">


        <center><h1 class="pt-4 mb-5">Tafel <?php echo e($usersPerTable[$table_id][0]->table_id); ?> / Ronde 1</h1></center>
        <form action="<?php echo e(url("/gamePoints")); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="row">

        <?php if(Auth::user()->isAdmin() || Auth::user()->isJudge()): ?>

        <?php for($i=0; $i < $usersOnTable ; $i++): ?>
            <br>

                <div class="col-md-6 mb-5">
                    <div class="card">
                        <div class="card-header"><center><strong><?php echo e($usersPerTable[$table_id][$i]->name); ?> <?php echo e($usersPerTable[$table_id][$i]->lastName); ?>

                                </strong></center>
                        </div>

                        <div class="card-body">

                                <div class="form-group col-md-12">
                                    <input type="number" class="form-control" value="<?php echo e($usersPerTable[$table_id][$i]->game_points); ?>" placeholder="Game points" name="<?php echo e($usersPerTable[$table_id][$i]->id); ?>">

                                </div>

                        </div>
                    </div>
                </div>
            <?php endfor; ?>


                </div>
            <input type="submit" value="SCORES DOORVOEREN" class="btn btn-success">

        </form>
            </div>



        <?php endif; ?>

    </div>

    </div>
    <center><a href="<?php echo e(url('/scores')); ?>"><button class="mb-4 btn btn-primary"><i class="fas fa-angle-left"></i> naar tafels</button></a></center>
<?php $__env->stopSection(); ?>















<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>