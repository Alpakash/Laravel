<div class="container">
    <center><h1 class="mt-4 mb-4">Ronde 1</h1></center>
    <div class="row">

        <?php if(Auth::user()->isAdmin() || Auth::user()->isJudge()): ?>
            
            <?php for($i=0; $i < $totalTables; $i++): ?>
                <div class="col-md-3">
                    <div class="card mb-4">
                        <a href="/score/<?php echo e($i); ?>" class="tableLinks">
                            <div class="card-header"><center><strong>Tafel <?php echo e($i + 1); ?></strong></center></div>

                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th scope="col">Naam</th>
                                        <th scope="col">Punten</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <ol>
                                    <?php if(array_has($usersPerTable, $i.'.0')): ?>
                                        <tr>
                                            <td>1. <?php echo e($usersPerTable[$i][0]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][0]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    <?php if(array_has($usersPerTable, $i.'.1')): ?>
                                        <tr>
                                            <td>2. <?php echo e($usersPerTable[$i][1]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][1]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    <?php if(array_has($usersPerTable, $i.'.2')): ?>
                                        <tr>
                                            <td>3. <?php echo e($usersPerTable[$i][2]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][2]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    
                                    <?php if(array_has($usersPerTable, $i.'.3')): ?>
                                        <tr>
                                            <td>4. <?php echo e($usersPerTable[$i][3]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][3]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    </ol>
                                    </tbody>
                                </table>

                            </div>
                        </a>
                    </div>

                </div>
            <?php endfor; ?>
            <a href="#"><button class="btn btn-success float-right">Volgende ronde <i class="fas fa-chevron-right"></i></button></a>


        <?php elseif(Auth::user()->isUser() || Auth::user()->isStores()): ?>
            
            <?php for($i=0; $i < $totalTables; $i++): ?>
                <div class="col-md-3">
                    <div class="card mb-4">
                            <div class="card-header"><center><strong>Tafel <?php echo e($i + 1); ?></strong></center></div>

                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th scope="col">Naam</th>
                                        <th scope="col">Punten</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(array_has($usersPerTable, $i.'.0')): ?>
                                        <tr>
                                            <td><?php echo e($usersPerTable[$i][0]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][0]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    <?php if(array_has($usersPerTable, $i.'.1')): ?>
                                        <tr>
                                            <td><?php echo e($usersPerTable[$i][1]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][1]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    <?php if(array_has($usersPerTable, $i.'.2')): ?>
                                        <tr>
                                            <td><?php echo e($usersPerTable[$i][2]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][2]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>

                                    
                                    <?php if(array_has($usersPerTable, $i.'.3')): ?>
                                        <tr>
                                            <td><?php echo e($usersPerTable[$i][3]->name); ?></td>
                                            <td><?php echo e($usersPerTable[$i][3]->tournament_points); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>
                    </div>

                </div>
            <?php endfor; ?>
        <?php endif; ?>
    </div>

</div>
