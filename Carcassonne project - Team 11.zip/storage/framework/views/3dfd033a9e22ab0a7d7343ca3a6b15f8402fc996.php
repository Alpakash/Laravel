 <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-5">
                <div class="card-header"><strong>News</strong>
                </div>

                <div class="card-body">
                    <div class="accordion" id="accordionExample">
                        <div class="card">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#index<?php echo e($news->id); ?>" aria-expanded="true" aria-controls="index<?php echo e($news->id); ?>">
                                            <?php echo e($news->title); ?>

                                        </button>
                                    </h5>
                                </div>


                                <div id="index<?php echo e($news->id); ?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">

                                        <strong style="text-align: right"><?php echo e($news->created_at); ?></strong>
                                        <p> <?php echo e($news->desc); ?></p>
                                        <?php if(Auth::user()->isAdmin() || Auth::user()->isJudge()): ?>

                                        <span style="display: inline-block">
                                            <a href='<?php echo e(url("/admin/news/{$news->id}/edit")); ?>'>
                                                    <button style="display: inline-block" class="float-left btn btn-warning">Edit artikel</button>
                                                </a>

                                               <form style="display: inline-block" action="<?php echo e(url("/admin/news/{$news->id}")); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                   <?php echo method_field('delete'); ?>
                                                    <input type="submit" value="DELETE" class="btn mt-2 btn-sm btn-danger">
                                                </form>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                </div>
                </div>
            </div>

        </div>
            <?php if(Auth::user()->isAdmin() || Auth::user()->isJudge()): ?>
     <center><a href="/admin/news/create"><button class="mt-5 btn btn-primary">Creëer artikel</button></a></center>
            <?php endif; ?>
 </div>

</div>