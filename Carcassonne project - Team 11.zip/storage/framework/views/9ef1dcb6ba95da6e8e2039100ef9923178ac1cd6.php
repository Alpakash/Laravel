<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>NK Carcassonne</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Your custom styles (optional) -->
<link href="<?php echo e(asset('css/mdb.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/style.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

<?php echo NoCaptcha::renderJs(); ?>