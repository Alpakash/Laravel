<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
<!-- Initializations -->
<script type="text/javascript" src="<?php echo e(asset('js/admin.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/auth.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('DataTables/datatables.min.js')); ?>"></script>

<script src="https://cdn.datatables.net/plug-ins/1.10.15/api/row().show().js"></script>