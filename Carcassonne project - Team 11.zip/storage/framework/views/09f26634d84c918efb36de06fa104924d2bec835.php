<?php echo e($news); ?>

