
    <nav class="navbar  navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="https://upload.wikimedia.org/wikipedia/it/3/38/Carcassonne_Logo.png" width="100px">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>
                <!-- Countdown Timer JavaScript-->
                    <?php echo $__env->make('layouts.countdown', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item">
                            <?php if(Route::has('register')): ?>
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            <?php endif; ?>
                        </li>
                    <?php else: ?>

                        <?php if(Auth::user()->isAdmin()): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/admin')); ?>"><button class="btn btn-primary mr-3"> Admin Dashboard</button></a>
                        </li>
                            <?php elseif(Auth::user()->isJudge()): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(url('/judge')); ?>"><button class="btn btn-primary mr-3"> Judge Page</button></a>
                                </li>
                        <?php endif; ?>

                    <li class="nav-item">
                         <a href="<?php echo e(url('/profile')); ?>"><button class="btn btn-success mr-3"> <i class="fas fa-user"></i> Mijn Profiel</button></a>
                    </li>


                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class=" dropdown-toggle btn btn-warning" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                               Menu <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                 <a class="dropdown-item" href="<?php echo e(url('/news')); ?>">
                                  <i class="far fa-newspaper"></i>  News
                                </a>
                                 <a class="dropdown-item" href="<?php echo e(url('/faq')); ?>">
                                   <i class="fas fa-question"></i> FAQ
                                </a>
                                 <a class="dropdown-item" href="<?php echo e(url('/scores')); ?>">
                                  <i class="far fa-star"></i>  Scores
                                </a>
                                <?php if(Auth::user()->isJudge() || Auth::user()->isAdmin()): ?>
                                <a class="dropdown-item" href="<?php echo e(url('/judge')); ?>">
                                   <i class="fas fa-crown"></i> Judge
                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                  <i class="fas fa-sign-out-alt"></i>  <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                               </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
