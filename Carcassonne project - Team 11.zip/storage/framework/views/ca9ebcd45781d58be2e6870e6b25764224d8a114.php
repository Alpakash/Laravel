<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="card mb-4 mt-5">
			<div class="card-header">
				<strong>Generate knop</strong>
			</div>
			<div class="card-body ">
		<form action="<?php echo e(url('/generateRound')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<center><input onclick="return confirm('Wil je de eerste ronde genereren?');" class="btn btn-success" type="submit" value="Genereer de eerste ronde"></center>
		</form>
			</div>
		</div>


		<div class="card mb-4 mt-5">
			<div class="card-header">
				<strong>Countdown timer</strong>
			</div>
			<div class="card-body ">
		<!-- Countdown Timer JavaScript-->
		<?php echo $__env->make('layouts.cd-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
		</div>

	
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>